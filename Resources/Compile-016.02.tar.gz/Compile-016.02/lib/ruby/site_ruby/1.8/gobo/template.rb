#!/usr/bin/ruby (require)

# GoboLinux template for creating Ruby classes/libraries

class GoboFoo
  public        # Public attributes
  private       # Private instance/class variables
  public        # Public methods
    def initialize()
    end
  protected     # Protected methods
  private       # Private methods
end

