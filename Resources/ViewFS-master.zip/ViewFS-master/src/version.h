
#ifndef VERSION_H
#define VERSION_H

int compare_versions(char* v1, char* v2);

#endif
