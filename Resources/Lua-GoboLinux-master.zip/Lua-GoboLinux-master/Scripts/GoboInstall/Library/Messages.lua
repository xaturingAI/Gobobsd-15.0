-- vi: set foldmethod=marker foldlevel=0:
--
-- Messages.lua
-- ---------------------------------------------------------------------------
--  - 2008
-- ---------------------------------------------------------------------------
-- Author: Aitor Pérez Iturri - <aitor.iturri@gmail.com>	
-- Created: 02/02/08 00:26:26 CET
-- License: GNU GPL (see www.fsf.org for details)
-- ---------------------------------------------------------------------------
-- Description:
--
-- ---------------------------------------------------------------------------

-- Imports

-- Local Variables
local en = {

}
-- Exported Variables

-- Local Functions

-- Exported Functions

-- Types

