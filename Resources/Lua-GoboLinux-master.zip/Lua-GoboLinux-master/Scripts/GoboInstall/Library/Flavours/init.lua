-- vi: set foldmethod=marker foldlevel=0:
--
-- Flavours.lua
-- ---------------------------------------------------------------------------
--  - 2008
-- ---------------------------------------------------------------------------
-- Author: Aitor Pérez Iturri - <aitor.iturri@gmail.com>	
-- Created: 01/02/08 10:24:54 CET
-- License: GNU GPL (see www.fsf.org for details)
-- ---------------------------------------------------------------------------
-- Description:
--
-- ---------------------------------------------------------------------------

-- Imports

-- Exported Variables
FlavoursList = {
	GoboPBX = true,
	GoboPBXBusyBox = true,
	SChroot = true,
}

-- Local Functions

-- Exported Functions

