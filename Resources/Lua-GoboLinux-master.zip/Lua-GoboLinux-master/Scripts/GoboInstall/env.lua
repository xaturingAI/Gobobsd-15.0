-- vi: set foldmethod=marker foldlevel=0:
--
-- env.lua
-- ---------------------------------------------------------------------------
--  - 2007
-- ---------------------------------------------------------------------------
-- Author: Aitor Pérez Iturri - <aitor.iturri@gmail.com>	
-- Created: 04/12/07 18:39:11 CET
-- License: GNU GPL (see www.fsf.org for details)
-- ---------------------------------------------------------------------------
-- Description:
--
-- ---------------------------------------------------------------------------
--
package.cpath = "../../1.0/lib/lua/5.1/?.so;"..package.cpath
package.path = "/Depot/Users/eof/Proyectos/Lua-Gobo/1.0/Shared/lua/5.1/?.lua;/Depot/Users/eof/Proyectos/Lua-Gobo/Scripts/GoboInstall/Library/?.lua;/Depot/Users/eof/Proyectos/Lua-Gobo/Scripts/GoboInstall/Library/?/init.lua;"..package.path

