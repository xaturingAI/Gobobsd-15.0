/*
 * =====================================================================================
 *
 *       Filename:  callbacks.c
 *
 *    Description:  
 *
 *        Version:  1.0
 *        Created:  22/11/07 01:20:35 CET
 *       Revision:  none
 *       Compiler:  gcc
 *
 *         Author:  Aitor Pérez Iturri (api), aitor.iturri@gmail.com
 *        Company:  ia Systems
 *
 * =====================================================================================
 */

#include	"luaarchive.h"
#include	"callbacks.h"


	int
callback_open ( archive_p a, void * clientdata )
{
	
}		/* -----  end of function callback_open  ----- */
/*int callback_open (archive_p a, void * userdata) {

}
int callback_close (archive_p, void *);
ssize_t callback_read (archive_p, void *, void **);
ssize_t callback_write (archive_p, void *, void *, size_t);
int callback_skip (archive_p, void *, size_t);*/

