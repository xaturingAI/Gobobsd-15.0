<div style='width:700px;'>

<h3>GoboLinux Recipe Viewer Bug Reports & Feedback Page</h3>

<p>If you encounter any <b>bugs</b> using the GoboLinux Recipe Viewer,
please do one of the following:</p>

<ul>

<li>Email a bug report to <a
href='mailto:mpb.mail@gmail.com'>mpb.mail@gmail.com</a>.</li>

</ul>

<p>If you have general <b>suggestions or feature requests</b> for the
GoboLinux Recipe Viewer, you may use either of the above links, or
alternatively you may mail your suggestions to the gobo-users or
gobo-devel mailing lists for discussion.</p>

<p>Thank you for using GoboLinux!</p>

</div>
